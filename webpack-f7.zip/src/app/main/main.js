import './main.less';

import Xhr from '../utils/xhr';
import mainHtml from './main.tpl.html';
import Tool from '../utils/tool';
import Constant from '../utils/constant';
import Picker from '../components/picker';

export default {
    init(){
        var that = this;
        //下面的初始化函数必须按一定顺序。即必须先有dom文档
        this.renderMainTpl();
        this.setAvatar(Constant.AVATAR);
        this.showPicker();
        Tool.setQuery(); 
        this.bindEvent();
    },
    
    bindEvent(){
        // var self = this;
        // var events = [
        //     {
        //         target: 'li.comment-list',
        //         event: 'click',
        //         handler: self.getUsr
        //     }
        // ];
        // Tool.bindEvents(events);
    },

    getUsr(){
        document.addEventListener('deviceready', function(){
            console.log(1)
          cordova.exec(function(result) {
              console.log("获取用户登录信息成功");
              alert(result.name)
           }, function(error) { 
              console.log("获取用户登录信息失败");
           }, "WorkPlus_Contact", "getUserInfo",[]);
        }, false);
    },

    renderMainTpl() {
        $('.main-page .page-content').html(mainHtml);
    },

    showPicker() {
        var defaults = [
            {
                input: '#picker-device',
                cols: [
                    {
                        textAlign: 'center',
                        values: ['2015-2016', '2016-2017']
                    }
                ]
            },
            {
                input: '#picker-device-2',
                cols: [
                    {
                        textAlign: 'center',
                        values: ['第一学期', '第二学期']
                    }
                ]
            }
        ]

        var pickerArr = Picker.showPicker(defaults);
    },

    setAvatar(pic){
        var _avatarElm = $('.avatar.thumb-lg img');
        _avatarElm.attr('src', pic);
    }
};