'use strict';

export default {
    show(){
        myApp.showIndicator();
    },
    hide(){
        myApp.hideIndicator();
    }
};