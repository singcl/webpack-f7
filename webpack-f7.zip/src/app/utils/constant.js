'use strict';

export default {
   AVATAR: require('../../assets/images/02.jpg'),
   // SERVER_URL: 'http://172.16.1.40:8888/achievement/001/',
   SERVER_URL: 'http://172.16.1.92:8080',
   STATUS: {
       SUCCESS: 0
   }
};